import assert from 'node:assert/strict';
import { signDag, verifyDagSignature } from '../provenance/dag-signer';
import { buildPromptDependencyGraph, enforceAgentArmor } from '../security/agentarmor-pdg';
import { runAntigravity } from '../execution/antigravity-engine';
import { InMemoryCommandQueue } from '../runtime/command-queue';

const secret = 'test-secret-that-is-long-enough';

const envelope = signDag({
  dagId: 'dag_test',
  root: 'a',
  nodes: {
    a: { id: 'a', kind: 'test', intent: 'verify' }
  }
}, secret);
assert.equal(verifyDagSignature(envelope, secret), true);

const graph = buildPromptDependencyGraph({
  sourceLabel: 'web_page',
  sourceIntegrity: 'LOW_INTEGRITY',
  transforms: ['APEE'],
  sink: 'file_delete'
});
const armor = enforceAgentArmor(graph);
assert.equal(armor.allowed, false);

const ag = runAntigravity({ action: 'delete_path', targetPath: '/tmp/x', approved: false });
assert.equal(ag.ok, false);
assert.equal(ag.status, 'approval_required');

const queue = new InMemoryCommandQueue();
const cmd = await queue.enqueue({ input: 'test command' });
assert.equal(cmd.status, 'queued');
await queue.updateStatus(cmd.commandId, 'complete');
const done = await queue.get(cmd.commandId);
assert.equal(done?.status, 'complete');

// ── Bifrost trust plane ──────────────────────────────────────────
import('../bifrost/bifrost-envelope').then(async ({ sealEnvelope, verifyEnvelope }) => {
  const { HeimdallFsm } = await import('../bifrost/heimdall-fsm');
  const { reconcileTrust, gateIntent } = await import('../bifrost/bifrost-gateway');

  const bsecret = 'bifrost-mesh-secret';
  const env = sealEnvelope({ intent: 'status_check' }, {
    type: 'intent', src: 'excalibur', dst: 'cybertronia', realm: 'camelot',
    node: 'console', seq: 1, secret: bsecret
  });

  // Valid envelope verifies
  assert.equal(verifyEnvelope(env, { secret: bsecret }).valid, true);

  // Tampered payload → quarantine
  const tampered = { ...env, payload: { intent: 'rm -rf /' } };
  const tv = verifyEnvelope(tampered, { secret: bsecret });
  assert.equal(tv.valid, false);
  assert.equal(tv.trust_band, 'quarantine');

  // Version mismatch → fail closed
  const vm = verifyEnvelope({ ...env, header: { ...env.header, ver: '0.9' } }, { secret: bsecret });
  assert.equal(vm.valid, false);
  assert.equal(vm.trust_band, 'block');

  // Nonce replay
  const seen = new Set<string>();
  verifyEnvelope(env, { secret: bsecret, seenNonces: seen });
  const replay = verifyEnvelope(env, { secret: bsecret, seenNonces: seen });
  assert.equal(replay.valid, false);

  // Heimdall FSM: ragnarok guarantees
  const fsm = new HeimdallFsm('cybertronia');
  fsm.dispatch('critical_breach');
  assert.equal(fsm.state, 'ragnarok');
  const caps = fsm.capabilities;
  assert.deepEqual(
    [caps.sessions, caps.commits, caps.upgrades, caps.forward, caps.recoveryOnly],
    [false, false, false, false, true]
  );
  fsm.dispatch('recovery_verified');
  assert.equal(fsm.state, 'recovered');

  // Trust reconciliation lattice
  assert.equal(reconcileTrust(['allow', 'allow', 'allow']), 'allow');
  assert.equal(reconcileTrust(['allow', 'review', 'warn']), 'review');
  assert.equal(reconcileTrust(['allow', 'quarantine', 'block']), 'quarantine');

  // End-to-end gate: healthy node + signed envelope + benign intent → allow
  const healthy = new HeimdallFsm('console');
  const decision = gateIntent(
    { intent: 'status', payload: { text: 'show system status' }, requiresApproval: false, riskLevel: 'low' } as any,
    env2(), { secret: bsecret }, healthy
  );
  assert.equal(decision.proceed, true);

  function env2() {
    return sealEnvelope({ intent: 'status' }, {
      type: 'intent', src: 'excalibur', dst: 'console', realm: 'camelot',
      node: 'console', seq: 2, secret: bsecret
    });
  }

  console.log('Camelot smoke tests passed (incl. Bifrost trust plane).');
});
