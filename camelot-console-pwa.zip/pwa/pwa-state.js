/**
 * Camelot Console — PWA session state machine.
 * Bridge-chapter law: the PWA updates ONLY from broker events / API calls.
 * It never infers trust or session state locally, so this is a strict
 * transition table — unknown (state, event) pairs are rejected.
 */

export const STATES = [
  'idle', 'node_selected', 'trust_checking', 'trust_approved',
  'trust_review_required', 'trust_denied', 'grant_requested', 'grant_issued',
  'grant_denied', 'signaling_pending', 'offer_sent', 'answer_received',
  'ice_exchange', 'connecting', 'active', 'revoke_requested', 'revoked', 'closed'
];

/** from-state → { broker event or API call → to-state } */
export const TRANSITIONS = {
  idle:                  { 'POST /api/v1/trust/lookup': 'node_selected' },
  node_selected:         { 'trust.lookup.started': 'trust_checking' },
  trust_checking:        { 'trust.lookup.approved': 'trust_approved',
                           'trust.lookup.review_required': 'trust_review_required',
                           'trust.lookup.denied': 'trust_denied' },
  trust_review_required: { 'trust.lookup.approved': 'trust_approved',
                           'trust.lookup.denied': 'trust_denied' },
  trust_approved:        { 'POST /api/v1/sessions': 'grant_requested' },
  grant_requested:       { 'session.granted': 'grant_issued',
                           'session.denied': 'grant_denied' },
  grant_issued:          { 'session.signaling_opened': 'signaling_pending',
                           'session.revoked': 'revoked' },
  signaling_pending:     { 'signaling.offer.forwarded': 'offer_sent',
                           'session.revoked': 'revoked' },
  offer_sent:            { 'signaling.answer.forwarded': 'answer_received',
                           'session.revoked': 'revoked' },
  answer_received:       { 'signaling.ice.forwarded': 'ice_exchange',
                           'session.revoked': 'revoked' },
  ice_exchange:          { 'session.connecting': 'connecting',
                           'session.revoked': 'revoked' },
  connecting:            { 'session.active': 'active',
                           'session.revoked': 'revoked' },
  active:                { 'POST /api/v1/sessions/{id}/revoke': 'revoke_requested',
                           'session.revoked': 'revoked' },
  revoke_requested:      { 'session.revoked': 'revoked' },
  revoked:               { 'session.closed': 'closed' },
  trust_denied:          { reset: 'idle' },
  grant_denied:          { reset: 'idle' },
  closed:                { reset: 'idle' }
};

/** Authorization column of the spec table — display truth, still broker-derived. */
export const AUTHORIZATION = {
  idle: 'No session', node_selected: 'Pending', trust_checking: 'Pending',
  trust_approved: 'Session may proceed', trust_review_required: 'Human approval required',
  trust_denied: 'Session denied', grant_requested: 'Pending',
  grant_issued: 'Session authorized', grant_denied: 'Session denied',
  signaling_pending: 'Authorization in progress', offer_sent: 'Transport setup in progress',
  answer_received: 'Transport setup in progress', ice_exchange: 'Transport setup in progress',
  connecting: 'Authorization active', active: 'Full operator access granted',
  revoke_requested: 'Termination requested', revoked: 'Access removed',
  closed: 'Terminal state'
};

export class PwaSession {
  constructor() {
    this.state = 'idle';
    this.history = [];
  }

  /** Apply a broker event. Returns {ok, state, rejected?}. Never infers. */
  dispatch(event) {
    const next = (TRANSITIONS[this.state] ?? {})[event];
    if (!next) {
      return { ok: false, state: this.state, rejected: event };
    }
    this.history.push({ from: this.state, event, to: next, ts: Date.now() });
    this.state = next;
    return { ok: true, state: next };
  }

  get authorization() {
    return AUTHORIZATION[this.state];
  }
}
