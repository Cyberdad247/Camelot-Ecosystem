import assert from 'node:assert/strict';
import { PwaSession, STATES, TRANSITIONS, AUTHORIZATION } from '../pwa-state.js';

// Spec parity: all 18 states exist, each with an authorization line
assert.equal(STATES.length, 18);
for (const s of STATES) assert.ok(AUTHORIZATION[s], `no authorization for ${s}`);

// Happy path: full table walk to active, then revoke → closed
const s = new PwaSession();
const happy = [
  'POST /api/v1/trust/lookup', 'trust.lookup.started', 'trust.lookup.approved',
  'POST /api/v1/sessions', 'session.granted', 'session.signaling_opened',
  'signaling.offer.forwarded', 'signaling.answer.forwarded', 'signaling.ice.forwarded',
  'session.connecting', 'session.active'
];
for (const e of happy) assert.equal(s.dispatch(e).ok, true, `rejected ${e}`);
assert.equal(s.state, 'active');
assert.equal(s.authorization, 'Full operator access granted');
assert.equal(s.dispatch('POST /api/v1/sessions/{id}/revoke').state, 'revoke_requested');
assert.equal(s.dispatch('session.revoked').state, 'revoked');
assert.equal(s.dispatch('session.closed').state, 'closed');
assert.equal(s.dispatch('reset').state, 'idle');

// Review branch: human approval required, then approved
const r = new PwaSession();
r.dispatch('POST /api/v1/trust/lookup');
r.dispatch('trust.lookup.started');
assert.equal(r.dispatch('trust.lookup.review_required').state, 'trust_review_required');
assert.equal(r.authorization, 'Human approval required');
assert.equal(r.dispatch('trust.lookup.approved').state, 'trust_approved');

// Denial branches terminate
const d = new PwaSession();
d.dispatch('POST /api/v1/trust/lookup'); d.dispatch('trust.lookup.started');
assert.equal(d.dispatch('trust.lookup.denied').state, 'trust_denied');
assert.equal(d.dispatch('session.granted').ok, false); // dead end: only reset

// Broker can revoke mid-signaling
const m = new PwaSession();
['POST /api/v1/trust/lookup','trust.lookup.started','trust.lookup.approved',
 'POST /api/v1/sessions','session.granted','session.signaling_opened'].forEach(e => m.dispatch(e));
assert.equal(m.dispatch('session.revoked').state, 'revoked');

// NO LOCAL INFERENCE: unknown or out-of-order events are rejected, state holds
const x = new PwaSession();
assert.equal(x.dispatch('session.active').ok, false);
assert.equal(x.state, 'idle');
assert.equal(x.dispatch('made.up.event').ok, false);

// Every transition target is a declared state (table integrity)
for (const [from, evs] of Object.entries(TRANSITIONS)) {
  assert.ok(STATES.includes(from), `unknown from-state ${from}`);
  for (const to of Object.values(evs)) assert.ok(STATES.includes(to), `unknown to-state ${to}`);
}

console.log('pwa-state tests passed (18-state spec table).');
