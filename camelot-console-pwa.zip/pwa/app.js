import { PwaSession, STATES, AUTHORIZATION } from './pwa-state.js';

/* ── Realm topology from the crystal ─────────────────────────── */
const NODES = [
  { id: 'excalibur',   name: 'EXCALIBUR',   sub: 'Android · 8GB',  carts: 'Cmd_CTRL · Cyb_Research · KBA · Crystal_Ball · phone_claw' },
  { id: 'cybertronia', name: 'CYBERTRONIA', sub: 'VPS · 16GB',     carts: 'Bifrost_GW · Yggdrasil · Factory · Titan · CloudBrain' },
  { id: 'kba_midgard', name: 'KBA MIDGARD', sub: 'iOS',            carts: 'Lakesha_Avatar · KBA_Pills ×6 · Fonoster' }
];

const session = new PwaSession();
let selectedNode = null;
let pendingTimers = [];

/* ── DOM ─────────────────────────────────────────────────────── */
const $ = id => document.getElementById(id);
const nodesEl = $('nodes'), railEl = $('rail'), logEl = $('log');
const bandEl = $('band'), authEl = $('authline');
const btns = { grant: $('b-grant'), approve: $('b-approve'), deny: $('b-deny'), revoke: $('b-revoke'), reset: $('b-reset') };

NODES.forEach(n => {
  const el = document.createElement('div');
  el.className = 'node';
  el.innerHTML = `<h3>${n.name}</h3><div class="sub">${n.sub}</div><div class="carts">${n.carts}</div>`;
  el.addEventListener('click', () => selectNode(n, el));
  nodesEl.appendChild(el);
});

STATES.forEach(s => {
  const el = document.createElement('div');
  el.className = 'st';
  el.dataset.state = s;
  el.innerHTML = `<span class="dot"></span><span>${s}</span><span class="auth">${AUTHORIZATION[s]}</span>`;
  railEl.appendChild(el);
});

/* ── Heimdall log voice: terse, network-log, trust_band ──────── */
function log(line, cls = '') {
  const el = document.createElement('div');
  if (cls) el.className = cls;
  const ts = new Date().toISOString().slice(11, 23);
  el.textContent = `[${ts}] ${line}`;
  logEl.prepend(el);
}

/* ── Broker simulation: the ONLY writer of session state ─────── */
function broker(event, delay) {
  const t = setTimeout(() => {
    const r = session.dispatch(event);
    if (!r.ok) { log(`REJECT evt=${event} state=${session.state} · no local inference`, 'bad'); return; }
    log(`evt=${event} → state=${r.state}`, 'ev');
    render();
  }, delay);
  pendingTimers.push(t);
}

function clearBroker() { pendingTimers.forEach(clearTimeout); pendingTimers = []; }

function selectNode(n, el) {
  if (session.state !== 'idle') return log(`REJECT node_select · session=${session.state}`, 'warn');
  selectedNode = n;
  document.querySelectorAll('.node').forEach(x => x.classList.remove('sel'));
  el.classList.add('sel');
  log(`GET /api/v1/nodes → 3 nodes · target=${n.id}`, 'sys');
  session.dispatch('POST /api/v1/trust/lookup');
  log(`POST /api/v1/trust/lookup node=${n.id}`, 'ev');
  render();
  broker('trust.lookup.started', 350);
  // Cybertronia carries the Bifrost gateway: clean allow. Others: review path.
  if (n.id === 'cybertronia') {
    broker('trust.lookup.approved', 1100);
  } else {
    broker('trust.lookup.review_required', 1100);
  }
}

btns.grant.addEventListener('click', () => {
  session.dispatch('POST /api/v1/sessions');
  log('POST /api/v1/sessions', 'ev'); render();
  broker('session.granted', 500);
  broker('session.signaling_opened', 1000);
  broker('signaling.offer.forwarded', 1500);
  broker('signaling.answer.forwarded', 2000);
  broker('signaling.ice.forwarded', 2500);
  broker('session.connecting', 3000);
  broker('session.active', 3700);
});
btns.approve.addEventListener('click', () => { log('sovereign approval issued', 'sys'); broker('trust.lookup.approved', 250); });
btns.deny.addEventListener('click', () => { log('sovereign denial issued', 'sys'); broker('trust.lookup.denied', 250); });
btns.revoke.addEventListener('click', () => {
  clearBroker();
  session.dispatch('POST /api/v1/sessions/{id}/revoke');
  log('POST /api/v1/sessions/{id}/revoke', 'warn'); render();
  broker('session.revoked', 400);
  broker('session.closed', 1000);
});
btns.reset.addEventListener('click', () => {
  clearBroker();
  session.dispatch('reset');
  selectedNode = null;
  document.querySelectorAll('.node').forEach(x => x.classList.remove('sel'));
  log('reset → idle', 'sys'); render();
});

/* ── Render: state is read, never written, here ──────────────── */
const BAND = s =>
  s === 'active' || s === 'trust_approved' || s === 'grant_issued' ? ['allow', 'TRUST ALLOW']
  : s === 'trust_review_required' ? ['review', 'TRUST REVIEW']
  : s === 'trust_denied' || s === 'grant_denied' || s === 'revoked' ? ['deny', 'TRUST BLOCK']
  : ['', `TRUST ${s === 'idle' ? '—' : 'PENDING'}`];

function render() {
  const s = session.state;
  const idx = STATES.indexOf(s);
  document.querySelectorAll('.st').forEach((el, i) => {
    el.classList.toggle('now', i === idx);
    el.classList.toggle('done', i < idx && session.history.some(h => h.to === el.dataset.state));
  });
  const [cls, label] = BAND(s);
  bandEl.className = cls; bandEl.textContent = label;
  authEl.textContent = session.authorization;

  btns.grant.disabled = s !== 'trust_approved';
  btns.approve.disabled = s !== 'trust_review_required';
  btns.deny.disabled = !(s === 'trust_review_required' || s === 'trust_checking');
  btns.revoke.disabled = !['grant_issued','signaling_pending','offer_sent','answer_received','ice_exchange','connecting','active'].includes(s);
  btns.reset.disabled = !['trust_denied','grant_denied','closed'].includes(s);
}

/* ── PWA machinery ───────────────────────────────────────────── */
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('sw.js')
    .then(() => { $('swstate').textContent = 'SW ACTIVE'; log('service worker registered · shell cached', 'ok'); })
    .catch(() => { $('swstate').textContent = 'SW FAIL'; });
}
let deferredPrompt = null;
addEventListener('beforeinstallprompt', e => {
  e.preventDefault(); deferredPrompt = e; $('install').style.display = 'inline-block';
});
$('install').addEventListener('click', async () => {
  if (!deferredPrompt) return;
  deferredPrompt.prompt();
  await deferredPrompt.userChoice;
  deferredPrompt = null; $('install').style.display = 'none';
});
addEventListener('online',  () => { $('net').textContent = 'MESH ONLINE'; $('net').className = ''; log('route_ready · advertise', 'ok'); });
addEventListener('offline', () => { $('net').textContent = 'MESH LOST'; $('net').className = 'off'; log('route_lost · block new grants', 'bad'); });

log('console boot · pwa_shell · broker events only', 'sys');
render();
