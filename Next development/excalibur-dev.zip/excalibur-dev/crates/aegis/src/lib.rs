//! excalibur-aegis :: eBPF + regex PII redaction
//! [STATUS: STUB]  EXCALIBUR v1000.0.0 component crate.

/// Component liveness probe. Replace with real logic per tasks.md.
pub fn online() -> bool { true }

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn boots() { assert!(online()); }
}
