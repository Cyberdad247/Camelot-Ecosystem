"""Aegis Shield :: regex PII redaction layer. [STATUS: WIRED]

The eBPF layer lives in crates/aegis (STUB); this is the userspace regex
fallback that runs today and gates all I/O when BTF/eBPF is unavailable.
"""
from __future__ import annotations
import re

_PATTERNS = {
    "EMAIL": re.compile(r"\b[\w.%+-]+@[\w.-]+\.[A-Za-z]{2,}\b"),
    "SSN":   re.compile(r"\b\d{3}-\d{2}-\d{4}\b"),
    "PHONE": re.compile(r"\b(?:\+?1[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b"),
    "CARD":  re.compile(r"\b(?:\d[ -]?){13,16}\b"),
}

def redact(text: str) -> str:
    """Return text with detected PII replaced by [REDACTED:<KIND>]."""
    out = text
    for kind, pat in _PATTERNS.items():
        out = pat.sub(f"[REDACTED:{kind}]", out)
    return out

def scan(text: str) -> dict[str, int]:
    """Return counts of each PII kind detected (no redaction)."""
    return {k: len(p.findall(text)) for k, p in _PATTERNS.items()}
